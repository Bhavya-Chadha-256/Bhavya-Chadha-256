# Basic-SQL-Projects
This repo contains basic SQL projects.
